<?php

test('that true is true', function () {
    expect(true)->toBeTrue();
});
